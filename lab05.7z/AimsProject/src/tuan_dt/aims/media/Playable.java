package AimsProject.src.tuan_dt.aims.media;

public interface Playable {
  public void play();
}
