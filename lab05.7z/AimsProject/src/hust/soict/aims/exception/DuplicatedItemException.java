package hust.soict.aims.exception;

public class DuplicatedItemException extends Exception {

	public DuplicatedItemException() {
		// TODO Auto-generated constructor stub
	}

	public DuplicatedItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DuplicatedItemException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public DuplicatedItemException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DuplicatedItemException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
